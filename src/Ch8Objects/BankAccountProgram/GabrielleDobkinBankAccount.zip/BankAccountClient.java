package Ch8Objects.BankAccountProgram;

public class BankAccountClient {
    public static void main(String[] args) {
        BankAccountV2 andrew = new BankAccountV2("Andrew", 123456789, new Address(123,"sesame street","Larchmont","NY", 10538), new DateOfBirth(2,8,02));
        andrew.deposit(10000);
        System.out.println(andrew);
        andrew.withdraw(500);
        BankAccountV2 gaby = new BankAccountV2("Gaby",914245678, new Address(123,"sesame street","Larchmont","NY", 10538), new DateOfBirth(2,8,02),1313,1000000000);
    }


}
